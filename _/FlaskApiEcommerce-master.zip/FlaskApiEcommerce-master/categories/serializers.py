from shared.serializers import PageSerializer


class CategoryListSerializer(PageSerializer):
    resource_name = 'categories'
