import sys
import tags.views

sys.stdout.write('[+] Registering tags routes\n')
