from shared.serializers import PageSerializer


class TagListSerializer(PageSerializer):
    resource_name = 'tags'
