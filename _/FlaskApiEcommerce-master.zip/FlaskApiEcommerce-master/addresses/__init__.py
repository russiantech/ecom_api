import addresses.views
import sys

sys.stdout.write('[+] Registering addresses routes\n')
