import sys

import orders.views

sys.stdout.write('[+] Registering order views\n')
