import sys

import users.views

sys.stdout.write('[+] Registering routes for user\n')
